export NEO4J_HOME=${NEO4J_HOME-~/Downloads/neo4j-community-3.0.1}

if [ ! -f data-csv.zip ]; then
  echo  Downloading ...

  curl -OL https://cloudfront-files-1.publicintegrity.org/offshoreleaks/data-csv.zip
fi

# Need full path due to BUG in import tool with relative paths	
export DATA=${PWD}/import

echo Extracting, Preparing, Cleaning up data ...

unzip -o -j data-csv.zip -d $DATA

tr -d '\\' < $DATA/Addresses.csv > $DATA/Addresses_fixed.csv

sed -i '' -e '1,1 s/node_id/node_id:ID(Address)/'      $DATA/Addresses_fixed.csv
sed -i '' -e '1,1 s/node_id/node_id:ID(Officer)/'      $DATA/Officers.csv
sed -i '' -e '1,1 s/node_id/node_id:ID(Entity)/'       $DATA/Entities.csv
sed -i '' -e '1,1 s/node_id/node_id:ID(Intermediary)/' $DATA/Intermediaries.csv

sed -i '' -e '1 d' $DATA/all_edges.csv

for i in Entity Officer Intermediary; do 
   echo "node_id:START_ID($i),detail:IGNORE,node_id:END_ID(Address)" > $DATA/registered_address_$i.csv
done
grep ',registered address,' $DATA/all_edges.csv > $DATA/registered_address.csv

for i in Officer Intermediary; do 
for j in Officer Intermediary; do 
   echo "node_id:START_ID(${i}),detail:IGNORE,node_id:END_ID(${j})" > $DATA/similar_${i}_${j}.csv
done
done
grep ',similar name and address as,' $DATA/all_edges.csv > $DATA/similar.csv

echo 'node_id:START_ID(Entity),detail,node_id:END_ID(Entity)' > $DATA/related.csv
grep ',\(related entity\|same name and registration date as\),' $DATA/all_edges.csv >> $DATA/related.csv


for i in Entity Intermediary; do 
   echo "node_id:START_ID(Officer),detail,node_id:END_ID($i)" > $DATA/officer_of_$i.csv
done
tr '[:upper:]' '[:lower:]' < $DATA/all_edges.csv | grep -v ',\(intermediary of\|registered address\|similar name and address as\|same name and registration date as\|same address as\|related entity\),'  > $DATA/officer_of.csv

for i in Entity; do 
   echo "node_id:START_ID(Intermediary),detail,node_id:END_ID($i)" > $DATA/intermediary_of_$i.csv
done
sed -e 's/,intermediary of,/,,/' < $DATA/all_edges.csv > $DATA/intermediary_of.csv


echo  CSV Overview ...

head -1 $DATA/*.csv

echo  Importing ...


rm -rf $DATA/panama.db; $NEO4J_HOME/bin/neo4j-import --into $DATA/panama.db --nodes:Address $DATA/Addresses_fixed.csv --nodes:Entity $DATA/Entities.csv --nodes:Intermediary $DATA/Intermediaries.csv --nodes:Officer $DATA/Officers.csv \
           --relationships:REGISTERED_ADDRESS $DATA/registered_address_Officer.csv,$DATA/registered_address.csv \
           --relationships:REGISTERED_ADDRESS $DATA/registered_address_Entity.csv,$DATA/registered_address.csv \
           --relationships:REGISTERED_ADDRESS $DATA/registered_address_Intermediary.csv,$DATA/registered_address.csv \
           --relationships:RELATED $DATA/related.csv \
           --relationships:OFFICER_OF $DATA/officer_of_Entity.csv,$DATA/officer_of.csv \
           --relationships:OFFICER_OF $DATA/officer_of_Intermediary.csv,$DATA/officer_of.csv \
           --relationships:INTERMEDIARY_OF $DATA/intermediary_of_Entity.csv,$DATA/intermediary_of.csv \
           --relationships:SIMILAR $DATA/similar_Officer_Officer.csv,$DATA/similar.csv \
           --relationships:SIMILAR $DATA/similar_Officer_Intermediary.csv,$DATA/similar.csv \
           --relationships:SIMILAR $DATA/similar_Intermediary_Officer.csv,$DATA/similar.csv \
           --relationships:SIMILAR $DATA/similar_Intermediary_Intermediary.csv,$DATA/similar.csv \
           --ignore-empty-strings true --skip-duplicate-nodes true --skip-bad-relationships true --bad-tolerance  10000000 --multiline-fields=true     

echo  Imported Data Overview ...

$NEO4J_HOME/bin/neo4j-shell -path $DATA/panama.db -c 'MATCH (n) RETURN count(*) as nodes;'
$NEO4J_HOME/bin/neo4j-shell -path $DATA/panama.db -c 'MATCH ()-->() RETURN count(*) as relationships;'
$NEO4J_HOME/bin/neo4j-shell -path $DATA/panama.db -c 'MATCH (n) RETURN labels(n),count(*) ORDER BY count(*) DESC;'
$NEO4J_HOME/bin/neo4j-shell -path $DATA/panama.db -c 'MATCH (n)-[r]->(m) RETURN labels(n),type(r),labels(m),count(*) ORDER BY count(*) DESC;'
$NEO4J_HOME/bin/neo4j-shell -path $DATA/panama.db -c 'MATCH (n)-[r]->(m) RETURN collect(distinct labels(n)),type(r),collect(distinct labels(m)),count(*) ORDER BY count(*) DESC;'
$NEO4J_HOME/bin/neo4j-shell -path $DATA/panama.db -c 'MATCH (n)-[r]->(m) RETURN collect(distinct labels(n)),type(r),labels(m),count(*) ORDER BY count(*) DESC;'
$NEO4J_HOME/bin/neo4j-shell -path $DATA/panama.db -c 'MATCH (n)-[r]->(m) RETURN labels(n),type(r),collect(distinct labels(m)),count(*) ORDER BY count(*) DESC;'
$NEO4J_HOME/bin/neo4j-shell -path $DATA/panama.db -c 'MATCH ()-[r]->() RETURN type(r),r.detail,count(*) ORDER BY count(*) DESC;'

# IMPORT DONE in 23s 361ms. Imported:
#   839434 nodes
#   1265690 relationships
#   8211012 properties



# cut -d, -f 2 all_edges.csv | sort | uniq -c | sort -nr
# 319121 intermediary of
# 316472 registered address
# 277380 shareholder of
# 118589 Director of
# 105408 Shareholder of
# 46761 similar name and address as
# 36318 Records & Registers of
# 15151 beneficiary of
# 14351 Secretary of
# 4031 Beneficiary of
# 3146 same name and registration date as
# 1847 Beneficial Owner of
# 1418 Trustee of Trust of
# 1234 Trust Settlor of
# 1229 Authorised Person / Signatory of
# 1198 Protector of
# 1130 Nominee Shareholder of
#  960 same address as
#  622 related entity
#  583 Assistant Secretary of
#  409 Alternate Director of
#  320 Co-Trustee of Trust of
#  281 Officer of
#  272 Resident Director of
#  207 Auditor of
#  173 Correspondent Addr. of
#  123 Bank Signatory of
#  120 General Accountant of
#  101 Nominated Person of
