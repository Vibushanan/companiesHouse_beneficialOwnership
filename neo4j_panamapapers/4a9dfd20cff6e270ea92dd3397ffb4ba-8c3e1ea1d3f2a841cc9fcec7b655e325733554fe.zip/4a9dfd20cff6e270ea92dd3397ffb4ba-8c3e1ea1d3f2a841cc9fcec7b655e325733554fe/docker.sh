mkdir -p panama
cd panama
# load apoc from https://github.com/neo4j-contrib/neo4j-apoc-procedures/releases/tag/1.0.0
mkdir -p plugins
curl -L https://github.com/neo4j-contrib/neo4j-apoc-procedures/releases/download/1.0.0/apoc-1.0.0.jar -o plugins/apoc-1.0.0.jar
# load public panama-papers files from: https://offshoreleaks.icij.org/pages/database
if [ ! -f data-csv.zip ]; then curl -OL https://cloudfront-files-1.publicintegrity.org/offshoreleaks/data-csv.zip; fi
unzip -o -j data-csv.zip -d import
tr -d '\\' < import/Addresses.csv > import/Addresses_fixed.csv
export PORT=`date +%S`123
echo $PORT
export HERE=`pwd`
mkdir -p $HERE/data
rm -rf $HERE/data/*

export CONTAINER=`docker run \
    --name neo4j-panama \
    --detach \
    --publish=$PORT:7474 \
    --volume=$HERE/data:/data \
    --volume=$HERE/import:/var/lib/neo4j/import \
    --volume=$HERE/plugins:/plugins \
    --ulimit=nofile=40000:40000 \
    --env=NEO4J_dbms_memory_heap_maxSize=5000 \
    --env=NEO4J_dbms_memory_pagecache_size=500M \
    neo4j:3.0`


docker ps -f name=neo4j-panama

sleep 5

docker exec -i $CONTAINER /var/lib/neo4j/bin/neo4j-shell -f << EOF

match (n) detach delete n;
create constraint on (n:Node) assert n.node_id is unique;

USING PERIODIC COMMIT 10000
LOAD CSV WITH HEADERS FROM "file:///Addresses_fixed.csv" AS row MERGE (n:Node {node_id:row.node_id}) ON CREATE SET n = row, n:Address;
USING PERIODIC COMMIT 10000
LOAD CSV WITH HEADERS FROM "file:///Intermediaries.csv" AS row MERGE (n:Node {node_id:row.node_id})  ON CREATE SET n = row, n:Intermediary;
USING PERIODIC COMMIT 10000
LOAD CSV WITH HEADERS FROM "file:///Entities.csv" AS row MERGE (n:Node {node_id:row.node_id})        ON CREATE SET n = row, n:Entity;
USING PERIODIC COMMIT 10000
LOAD CSV WITH HEADERS FROM "file:///Officers.csv" AS row MERGE (n:Node {node_id:row.node_id})        ON CREATE SET n = row, n:Officer;

USING PERIODIC COMMIT
LOAD CSV WITH HEADERS FROM "file:///all_edges.csv" AS row
WITH row WHERE row.rel_type = "intermediary_of"
MATCH (n1:Node) WHERE n1.node_id = row.node_1
MATCH (n2:Node) WHERE n2.node_id = row.node_2
CREATE (n1)-[:INTERMEDIARY_OF]->(n2);

USING PERIODIC COMMIT
LOAD CSV WITH HEADERS FROM "file:///all_edges.csv" AS row
WITH row WHERE row.rel_type = "officer_of"
MATCH (n1:Node) WHERE n1.node_id = row.node_1
MATCH (n2:Node) WHERE n2.node_id = row.node_2
CREATE (n1)-[:OFFICER_OF]->(n2);

USING PERIODIC COMMIT
LOAD CSV WITH HEADERS FROM "file:///all_edges.csv" AS row
WITH row WHERE row.rel_type = "registered_address"
MATCH (n1:Node) WHERE n1.node_id = row.node_1
MATCH (n2:Node) WHERE n2.node_id = row.node_2
CREATE (n1)-[:REGISTERED_ADDRESS]->(n2);

USING PERIODIC COMMIT
LOAD CSV WITH HEADERS FROM "file:///all_edges.csv" AS row
WITH row WHERE row.rel_type = "similar"
MATCH (n1:Node) WHERE n1.node_id = row.node_1
MATCH (n2:Node) WHERE n2.node_id = row.node_2
CREATE (n1)-[:SIMILAR]->(n2);

USING PERIODIC COMMIT
LOAD CSV WITH HEADERS FROM "file:///all_edges.csv" AS row
WITH row WHERE row.rel_type = "underlying"
MATCH (n1:Node) WHERE n1.node_id = row.node_1
MATCH (n2:Node) WHERE n2.node_id = row.node_2
CREATE (n1)-[:UNDERLYING]->(n2);

DROP CONSTRAINT ON (n:Node) ASSERT n.node_id IS UNIQUE;

MATCH (n) REMOVE n:Node;

CREATE INDEX ON :Officer(name);
CREATE INDEX ON :Entity(name);
CREATE INDEX ON :Entity(address);
CREATE INDEX ON :Intermediary(name);
CREATE INDEX ON :Address(address);

// stats
MATCH (n)-[r]->(m)
RETURN labels(n),type(r),labels(m),count(*)
ORDER BY count(*) DESC;

schema await
EOF

echo "Neo4j running on $PORT mounted $HERE/data and $HERE/import container: $CONTAINER"
echo "To kill run: docker rm -f $CONTAINER"
